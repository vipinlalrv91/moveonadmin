module.exports={
    program: "INTERVAL MOBILE APP (backend)",
    version:"1.0.0",
    release:'01'
}